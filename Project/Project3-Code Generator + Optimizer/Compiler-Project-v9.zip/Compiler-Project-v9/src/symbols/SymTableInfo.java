package symbols;

public class SymTableInfo{
}