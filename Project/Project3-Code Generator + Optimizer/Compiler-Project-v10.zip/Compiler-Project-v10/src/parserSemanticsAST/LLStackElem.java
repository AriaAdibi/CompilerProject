package parserSemanticsAST;

public class LLStackElem{
}