package VM;

public enum OperandType {
	INT,
	FLOAT,
	BOOL,
	CHAR,
}
